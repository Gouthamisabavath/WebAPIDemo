﻿using Adminstories.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Adminstories.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class AdminController : ControllerBase
    {
        [HttpGet]
        [Route("Getadmincreds")]
        public IEnumerable<Admin> GetAdmincreds()
        {
            using (var context = new FlightBookingContext())
            {
                return context.Admin.ToList();
            }
        }

        [HttpGet]
        [Route("getairline")]
        public IEnumerable<AirlineaddBlock> Getairline()
        {
            using (FlightBookingContext context = new FlightBookingContext())
            {
                return context.AirlineaddBlock.ToList();
            }
        }


        [HttpGet]
        [Route("getscheduleairline")]
        public IEnumerable<AirlineSchedule> getschedule()
        {
            using (FlightBookingContext context = new FlightBookingContext())
            {
                return context.AirlineSchedule.ToList();
            }
        }

        // POST api/<AdminController>
        [HttpPost]
        [Route("Addairline")]
        public IActionResult Addairline([FromBody] AirlineaddBlock airlineaddBlock)
        {
            using (FlightBookingContext context = new FlightBookingContext())
            {
                airlineaddBlock.AddDate = System.DateTime.Now;
                airlineaddBlock.BlockedDate = Convert.ToDateTime("1900-01-01 00:00:00.000");
                airlineaddBlock.Status = "Active";
                context.AirlineaddBlock.Add(airlineaddBlock);
                context.SaveChanges();
                return Ok(new { success = 1 });
            }
        }

        [HttpPost]
        [Route("Scheduleairline")]
        public IActionResult scheduleairline([FromBody] AirlineSchedule airlineschedule)
        {
            using (FlightBookingContext context = new FlightBookingContext())
            {
                context.AirlineSchedule.Add(airlineschedule);
                context.SaveChanges();
                return Ok(new { success = 1 });
            }
        }

        [HttpDelete]
        [Route("blockairline")]
        public IActionResult Airline_Block(string AirlineId)
        {
            using (FlightBookingContext context = new FlightBookingContext())
            {
                var ids = from r in context.AirlineaddBlock where r.AirlineId == AirlineId select r;
                foreach (var r in ids)
                {
                    context.AirlineaddBlock.Remove(r);
                }
                context.SaveChanges();
                return Ok(new { success = 1 });
            }
        }
    }
}
