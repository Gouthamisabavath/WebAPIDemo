﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Adminstories.Models
{
    public partial class FlightBookingContext : DbContext
    {
        public FlightBookingContext()
        {
        }

        public FlightBookingContext(DbContextOptions<FlightBookingContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Admin> Admin { get; set; }
        public virtual DbSet<AirlineaddBlock> AirlineaddBlock { get; set; }
        public virtual DbSet<AirlineSchedule> AirlineSchedule { get; set; }
        public virtual DbSet<Register> Register { get; set; }
        public virtual DbSet<TblAirlines> TblAirlines { get; set; }
        public virtual DbSet<TicketBooking> TicketBooking { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning// To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=CTSDOTNET103;Database=FlightBooking;User id =sa;password=pass@word1");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Admin>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("id");

                entity.Property(e => e.Email)
                    .HasColumnName("email")
                    .HasMaxLength(60);

                entity.Property(e => e.Password)
                    .HasColumnName("password")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<AirlineaddBlock>(entity =>
            {
                entity.Property(e => e.AddDate).HasColumnType("datetime");

                entity.Property(e => e.AirlineId)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Airlinename)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.BlockedDate).HasColumnType("datetime");

                entity.Property(e => e.Status)
                    .HasMaxLength(10)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<AirlineSchedule>(entity =>
            {
                entity.Property(e => e.AirlineId)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.EndDatetime)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Fromplace)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.InstrumentUsed)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Meal)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.ScheduledDay)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.StartDatetime)
                    .HasMaxLength(60)
                    .IsUnicode(false);

                entity.Property(e => e.Ticketcharge).HasColumnType("money");

                entity.Property(e => e.ToPlace)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Register>(entity =>
            {
                entity.Property(e => e.Email).HasMaxLength(50);

                entity.Property(e => e.Gender)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Phonenumber)
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Username)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TblAirlines>(entity =>
            {
                entity.HasKey(e => e.Flightnumber);

                entity.Property(e => e.Destination)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Discount).HasColumnType("money");

                entity.Property(e => e.FinalTicketprice).HasColumnType("money");

                entity.Property(e => e.Flightlogo).IsUnicode(false);

                entity.Property(e => e.Flightname)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Flighttime).HasColumnType("datetime");

                entity.Property(e => e.Oneway)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.OnewayPrice).HasColumnType("money");

                entity.Property(e => e.Place)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Roundtrip)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.Sourse)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.TwowayPrice).HasColumnType("money");
            });

            modelBuilder.Entity<TicketBooking>(entity =>
            {
                entity.Property(e => e.Bookingdate)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Optformeal)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PassengerEmail).HasMaxLength(200);

                entity.Property(e => e.PassengerName)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.Seatnumbers)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Useremail)
                    .HasColumnName("useremail")
                    .HasMaxLength(80);

                entity.Property(e => e.Username)
                    .HasMaxLength(200)
                    .IsUnicode(false);
            });
        }
    }
}
