﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Userstories.Usermodel;

namespace Userstories.Controllers
{
   // [Authorize(Roles = "Admin")]
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
     
        [HttpPost]
        [Route("UserRegistration")]
        public IActionResult Registeruser([FromBody] Register userRegister)
        {
            using (FlightBookingContext fc = new FlightBookingContext())
            {
                fc.Register.Add(userRegister);
                fc.SaveChanges();
            }
            return Ok(new { success = 1 });
        }


        [HttpPost]
        [Route("Ticketbook")]
        public int BookingTicket([FromBody] TicketBooking ticket)
        {
            int Result;
            using (FlightBookingContext fc = new FlightBookingContext())
            {
                Random rmd = new Random();
                int PNR = rmd.Next(00000, 99999);
                Console.WriteLine("Your ticket booked successfully PNR is:" + PNR);
                Result = PNR;
                ticket.Pnrnumber = Result;
                fc.TicketBooking.Add(ticket);
                fc.SaveChanges();
            }

            return Result;
        }


        [Route("Alluserdetails")]
        [HttpGet]
        public IEnumerable<Register> Get()
        {
            using (var context = new FlightBookingContext())
            {
                return context.Register.ToList();
            }
        }

       
        [HttpGet]
        [Route("GetBookinghistory")]
        public IEnumerable<TicketBooking> Gettickethistory(string Email)
        {
            using (FlightBookingContext context = new FlightBookingContext())
            {
                return context.TicketBooking.Where(a => a.PassengerEmail == Email).ToList();

            }
        }


        [HttpDelete]
        [Route("CancelTicket")]
        public IActionResult Ticket_cancel(int Pnrnumber)
        {
            using (FlightBookingContext context = new FlightBookingContext())
            {
                var ids = from r in context.TicketBooking where r.Pnrnumber == Pnrnumber select r;
                foreach (var pnr in ids)
                {
                    context.TicketBooking.Remove(pnr);
                }
                context.SaveChanges();
                return Ok(new { success = 1 });
            }
        }

        [HttpGet]
        [Route("Getuser")]
        public Register Getuser(String Email)
        {
            using (FlightBookingContext context = new FlightBookingContext())
            {
                return context.Register.Where(a => a.Email == Email).FirstOrDefault();
            }
        }


        [HttpGet]
        [Route("SearchSourceDestination")]
        public IEnumerable<TblAirlines> SearchSourceDestination(string Source, string Destination)
        {
            using (FlightBookingContext fc = new FlightBookingContext())
            {
                return fc.TblAirlines.Where(m => m.Sourse == Source && m.Destination == Destination).ToList();
            }
        }

        [HttpGet]
        [Route("Oneway")]
        public IEnumerable<TblAirlines> Oneway(string Oneway)
        {
            using (FlightBookingContext fc = new FlightBookingContext())
            {
                return fc.TblAirlines.Where(m => m.Oneway == Oneway).ToList();
            }
        }

        [HttpGet]
        [Route("RoundTrip")]
        public IEnumerable<TblAirlines> RoundTrip(string RoundTrip)
        {
            using (FlightBookingContext fc = new FlightBookingContext())
            {
                return fc.TblAirlines.Where(m => m.Roundtrip == RoundTrip).ToList();
            }
        }

        [HttpGet]
        [Route("Datetimesearch")]
        public IEnumerable<TblAirlines> Datetimesearch(DateTime date)
        {
            //TblAirlines tbl = new TblAirlines();
            using (FlightBookingContext fc = new FlightBookingContext())
            {
                return fc.TblAirlines.Where(m => m.Flighttime == date).ToList();
            }
        }
    }
}
